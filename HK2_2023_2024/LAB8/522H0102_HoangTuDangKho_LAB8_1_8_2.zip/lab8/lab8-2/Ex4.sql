﻿Create database lab8_2
Use lab8_2


CREATE TABLE Lop (
  MaLop VARCHAR(10) PRIMARY KEY,
  TenLop VARCHAR(50)
)

CREATE TABLE Sinhvien (
  MaSV VARCHAR(10) PRIMARY KEY,
  HoTen VARCHAR(50),
  NgaySinh DATE,
  MaLop VARCHAR(10),
  FOREIGN KEY (MaLop) REFERENCES Lop(MaLop)
)

CREATE TABLE Monhoc (
  TenMH NVARCHAR(50),
  MaMH VARCHAR(10) PRIMARY KEY
  
)

CREATE TABLE Ketqua (
  MaSV VARCHAR(10),
  MaMH VARCHAR(10),
  Diem float,
  PRIMARY KEY (MaSV, MaMH),
  FOREIGN KEY (MaSV) REFERENCES Sinhvien(MaSV),
  FOREIGN KEY (MaMH) REFERENCES Monhoc(MaMH)
)



Insert into Lop values('LOP001', 'Anh Van')
Insert into Lop values('LOP002', 'Cong nghe thong tin')
Insert into Lop values('LOP003', 'Dien tu vien thong')
Insert into Lop values('LOP004', 'Quan tri kinh doanh')

Insert into Monhoc values('Anh van', 'AV')
Insert into Monhoc values('co so du lieu', 'CSDL')
Insert into Monhoc values('Ky thuat lap trinh', 'KTLT')
Insert into Monhoc values('Ke toan tai chinh', 'KTTC')
Insert into Monhoc values('Toan cao cap', 'TCC')
Insert into Monhoc values('Tin hoc van phong', 'THVP')
Insert into Monhoc values('Tri tue nhan tao', 'TTTNT')

Insert into Sinhvien values( 'S001','Tran Minh Son', '5/1/1985', 'LOP002')
Insert into Sinhvien values( 'S002','Nguyen Quoc Bao', '6/15/1986', 'LOP003')
Insert into Sinhvien values( 'S003','Phan Anh Tung', '12/20/1983', 'LOP003')
Insert into Sinhvien values( 'S004','Bui thi Anh Thu', '2/1/1985', 'LOP001')
Insert into Sinhvien values( 'S005','Le Thi Lan Anh', '7/3/1987', 'LOP004')
Insert into Sinhvien values( 'S006','Nguyen Thi Lam', '11/25/1984', 'LOP002')
Insert into Sinhvien values( 'S007','Phan thi Ha', '7/3/1988', 'LOP002')
Insert into Sinhvien values( 'S008','Tran The Dung', '10/21/1985', 'LOP001')

Insert into Ketqua values('S001', 'CSDL',6)
Insert into Ketqua values('S001', 'TCC',8)
Insert into Ketqua values('S002', 'CSDL',7)
Insert into Ketqua values('S003', 'KTTC',10)
Insert into Ketqua values('S004', 'AV',9)
Insert into Ketqua values('S004', 'THVP',2)
Insert into Ketqua values('S006', 'TCC',9)
Insert into Ketqua values('S007', 'AV',3)
Insert into Ketqua values('S007', 'KTLT',7)
Insert into Ketqua values('S008', 'AV',5.5)


--a



--b
Create function caub (@masv varchar(10))
Returns table
as
	Return(Select HoTen, ngaysinh, datename(dw,ngaysinh) as N'Thứ'
			From Sinhvien
			Where MaSV = @masv)
Select * from caub('S001')
--c
Create function cauc()
Returns table
as
	Return(Select sv.MaSV, HoTen, year(NgaySinh) as NamSinh, avg(Diem) as DTB
			From Sinhvien sv, KetQua k
			Where sv.MaSV = k.MaSV
			Group by sv.MaSV, HoTen, year(NgaySinh)
			Having avg(Diem) > 5)
Select * from cauc()

--d
Create function caud (@masv varchar(10))
Returns table
as
	Return (Select l.MaLop, TenLop
			From Lop l, Sinhvien sv
			Where @masv = sv.MaSV and
				  sv.MaLop = l.MaLop)
Select * from caud('S004')

--e
Create function caue (@mamh varchar(10))
Returns float
as
Begin
	Declare @avg float
	Select @avg = avg(Diem)
	From KetQua 
	Where @mamh = MaMH
	Return @avg
End
print dbo.caue('AV')

--f
Create function cau77 (@malop varchar(10))
Returns float
as
Begin
	Declare @maxdiem float

	Select @maxdiem = max(DTB)
	From( 
		Select avg(Diem) as DTB
		From KetQua kq, Sinhvien sv
		Where sv.MaSV = kq.MaSV and sv.MaLop = 'LOP002'
		Group by sv.MaSV
		)as dtb
	Return @maxdiem
End
Print dbo.cau77 ('LOP002')

