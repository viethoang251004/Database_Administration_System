Create database quanlyNGK
Use quanlyNGK


Create table nsx(
	mansx	varchar(10) primary key,
	tennsx	nvarchar(20)
)

Create table NGK(
	mangk	varchar(10) primary key,
	tenngk	nvarchar(20),
	dvt		nvarchar(10),
	soluong	int,
	dongia	float,
	maloai	varchar(10)
)

Create table hoadon(
	sohd	varchar(10) primary key,
	ngaylap	date
)

Create table cthd(
	sohd	varchar(10),
	mangk	varchar(10),
	soluong	int,
	dongia	float,
	primary key(sohd, mangk),
	constraint fk1 foreign key(sohd) references hoadon(sohd),
	constraint fk2 foreign key(mangk) references ngk(mangk)
)


--e
Create function cau_e(@sohd varchar(10))
Returns float
as
Begin
	Declare total float
	Select total = sum(soluong * dongia)
	From cthd
	Where sohd = @sohd
	Return total
End

--f
Create function cau_f()
Returns table
as
	Return(Select ngk.*
		   From NGK ngk, cthd ct, hoadon hd
		   Where ngk.mangk = ct.mangk and	
				 ct.sohd = hd.sohd and
				 year(hd.ngaylap) = 2016 and month(hd.ngaylap) = 3)