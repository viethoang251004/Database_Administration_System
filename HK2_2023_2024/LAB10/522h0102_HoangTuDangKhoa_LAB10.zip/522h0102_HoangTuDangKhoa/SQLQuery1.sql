Create database qlsv
Use qlsv

Create table lop
(
	malop	varchar(3) primary key,
	tenlop	nvarchar(20),
)

Create table sinhvien
(
	masv	varchar(5) primary key,
	hoten	nvarchar(30),
	ngaysinh	date,
	malop	varchar(3),
	constraint fk1 foreign key(malop) references lop(malop)
)

Create table monhoc
(
	mamh	varchar(3) primary key,
	tenmh	nvarchar(10),
	tinchi	int
)

Create table ketqua
(
	masv	varchar(5),
	mamh	varchar(3),
	diem	int,
	primary key(masv,mamh),
	constraint fk2 foreign key(masv) references sinhvien(masv),
	constraint fk3 foreign key(mamh) references monhoc(mamh)
)

--2
sp_addlogin	'login1','123','qlsv'
sp_adduser 'login1','login1'

sp_addlogin 'login2','234','QLBH'
sp_adduser 'login2','login2'

sp_addlogin	'login3','123','qlsv'
sp_adduser 'login3','login3'

--3
grant create table, delete , update 
to login3
--4
sp_addrole 'Selectdl'
grant select
to Selectdl
sp_addrolemember 'Selectdl', 'login1'
sp_addrolemember 'Selectdl', 'login3'