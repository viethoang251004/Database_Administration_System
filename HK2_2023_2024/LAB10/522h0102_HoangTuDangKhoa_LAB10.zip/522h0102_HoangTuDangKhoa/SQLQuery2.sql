Create database QLBH
Use QLBH

Create table loaihang
(
	maloaihang	varchar(10) primary key,
	tenloahang	nvarchar(50) not null
)

Create table khachhang
(
	makhachhang	varchar(10) primary key,
	tencongty	nvarchar(100) not null,
	tengiaodich	nvarchar(100) not null,
	diachi		nvarchar(100) not null,
	email		varchar(100) not null,
	dienthoai	varchar(10) not null,
	fax			varchar(10) not null
)

Create table nhacungcap
(
	macongty	varchar(10) primary key,
	tencongty	nvarchar(100) not null,
	tengiaodich	nvarchar(100) not null,
	diachi		nvarchar(100) not null,
	email		varchar(100) not null,
	dienthoai	varchar(10) not null,
	fax			varchar(10) not null
)

Create table nhanvien
(
	manhanvien	varchar(10) primary key,
	ho			nvarchar(50) not null,
	ten			nvarchar(10) not null,
	ngaysinh	smalldatetime,
	ngaylamviec	smalldatetime,
	diachi		nvarchar(100),
	dienthoai	varchar(10),
	luongcoban	float,
	phucap		float,
)

Create table dondathang
(
	sohoadon	varchar(10) primary key,
	makhachhang	varchar(10),
	manhanvien	varchar(10),
	ngaydathang	smalldatetime not null,
	ngaygiaohang smalldatetime not null,
	ngaychuyenhang smalldatetime not null,
	noigiaohang	nvarchar(100) not null
)
Alter table dondathang add constraint fk1 foreign key(makhachhang) references khachhang(makhachhang)
Alter table dondathang add constraint fk2 foreign key(manhanvien) references nhanvien(manhanvien)

Create table mathang
(
	mahang	varchar(10) primary key,
	tenhang	nvarchar(100) not null,
	macongty varchar(10),
	maloaihang varchar(10),
	soluong int,
	dvt nvarchar(10),
	giahang	float,
)
Alter table mathang add constraint fk3 foreign key(macongty) references nhacungcap(macongty)
Alter table mathang add constraint fk4 foreign key(maloaihang) references loaihang(maloaihang)

Create table chitietdathang
(
	sohoadon varchar(10),
	mahang	varchar(10),
	giaban	float,
	soluong int,
	mucgiamgia	float,
	primary key(sohoadon, mahang)
)
Alter table chitietdathang add constraint fk5 foreign key(mahang) references mathang(mahang)
Alter table chitietdathang add constraint fk6 foreign key(sohoadon) references dondathang(sohoadon)