﻿Create database QLTV
Use QLTV

Create table docgia
(
	madg	varchar(10) primary key,
	ho		nvarchar(10),
	tenlot	nvarchar(20),
	ten	nvarchar(10),
	ngaysinh	date
)

Create table nguoilon
(
	madg	varchar(10) primary key,
	sonha	varchar(20),
	duong	nvarchar(20),
	quan	nvarchar(20),
	dienthoai	varchar(10),
	han_sd	date,
	constraint fk1 foreign key (madg) references docgia(madg)
)

Create table treem
(
	madg	varchar(10) primary key,
	madg_nguoilon	varchar(10),
	constraint fk2 foreign key (madg) references docgia(madg),
	constraint fk3 foreign key (madg_nguoilon) references nguoilon(madg)
)

Create table tuasach
(
	matuasach	varchar(10) primary key,
	tuasach		nvarchar(30),
	tacgia		nvarchar(20),
	tomtat		nvarchar(200)
)

Create table dausach
(
	isbn	varchar(10),
	matuasach	varchar(10),
	ngonngu	nvarchar(10),
	bia		nvarchar(10),
	trangthai	nvarchar(20),
	primary key(isbn,matuasach),
	constraint fk4 foreign key(matuasach) references tuasach(matuasach)
)

Create table cuonsach
(	
	isbn	varchar(10),
	macuonsach	varchar(10),
	tinhtrang	nvarchar(20),
	primary key(isbn,macuonsach)
)


trigger insert
trigger update
trigger delete


--1

--2

--3
Create trigger tg_updCuonSach
On cuonsach
For update
as
Begin
	Update dausach
	Set trangthai = tinhtrang
	From dausach, cuonsach
	Where dausach.isbn = cuonsach.isbn
End


--4
Create trigger tg_InfThongBao
On tuasach
For insert, update, delete
as
Begin
	if exists (Select * 
				From inserted
				Where tacgia is not null or tuasach is not null)
	Begin
		Print N'Đã thêm mới tựa sách'
	End
End


--5
Create trigger tg_SuaSach
On tuasach
For update
as
Begin
	
End

--6
Create trigger tg_KiemTraTrung
On Tuasach
For insert
as
Begin
	If exists (Select tuasach from tuasach t, inserted where t.tuasach = inserted.tuasach)	
		Print N'Tựa sách đã tồn tại'
	Else
	Begin
		Insert into tuasach 
		Select inserted.matuasach, ínerted.tuasach, inserted.tacgia, inserted.tomtat
		From inserted
	End
End
