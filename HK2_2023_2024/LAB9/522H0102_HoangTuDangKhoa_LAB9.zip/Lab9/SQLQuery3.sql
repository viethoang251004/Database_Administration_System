﻿Create database QLS
Use QLS

Create table nhomsach
(
	manhom	char(5) primary key,
	tennhom	nvarchar(25)
)

Create table nhanvien
(
	manv	char(5) primary key,
	holot	nvarchar(25),
	tennv	nvarchar(10),
	phai	nvarchar(3),
	ngaysinh	smalldatetime,
	diachi	nvarchar(40)
)

Create table dmsach
(
	masach	char(5) primary key,
	tensach	nvarchar(40),
	tacgia	nvarchar(20),
	manhom	char(5),
	dongia	numeric(5),
	slton	numeric(5),
	constraint fk1 foreign key (manhom) references nhomsach(manhom)
)

Create table hoadon
(
	mahd	char(5) primary key,
	ngayban	smalldatetime,
	manv	char(5),
	constraint fk2 foreign key(manv) references nhanvien(manv)
)

Create table hoadon_luu
(
	mahd	char(5) primary key,
	ngayban	smalldatetime,
	manv	char(5),
	constraint fk5 foreign key(manv) references nhanvien(manv)
)

Create table chitiethoadon
(
	mahd	char(5),
	masach	char(5),
	soluong	numeric(5),
	primary key(mahd,masach),
	constraint fk3 foreign key(mahd) references hoadon(mahd),
	constraint fk4 foreign key(masach) references dmsach(masach)
)

--1
trigger insert

Create trigger cau1
On nhomsach
For insert
as
Begin
	Declare @count int
	Set @count = (Select count(*) from inserted)
	Print N'Có ' + CONVERT(NVARCHAR,@count) + N' mẫu tin được chèn'
	Rollback tran
End

Insert into nhomsach values('SACH3','Sach 1')

--2
trigger insert
Create trigger cau2
On hoadon
For insert
as
Begin
	insert into hoadon_luu
	select mahd, ngayban, manv
    from inserted
	Rollback tran
End


--3
trigger insert
trigger update
trigger delete

Alter table hoadon add tongtrigia numeric(5)

Create trigger cau3
on chitiethoadon
For insert, delete, update
as
Begin
	Update hoadon
	Set tongtrigia = (Select sum(soluong * dongia) 
					  From chitiethoadon ct, dmsach dm, hoadon hd
					  Where hd.mahd = ct.mahd and ct.masach = dm.masach)
	From hoadon hd, inserted, deleted
	Where hd.mahd = inserted.mahd or hd.mahd = deleted.mahd
End

--4
Alter table chitiethoadon add giaban numeric(5)
Create trigger cau4
On chitiethoadon
For insert, update
as
Begin
	If exists (Select *
				From inserted i, dmsach dm
				Where i.masach =  dm.masach and i.giaban != dm.dongia)
	Begin
		Print N'Ràng buộc liên thuộc tính không hợp lệ'
		Rollback tran
	End
End

--5
Create trigger cau5
On hoadon
For insert, update
As
Begin
    If exists (
        Select *
        FROM hoadon h, inserted i
        WHERE h.mahd = i.mahd and h.NgayBan < NgayLapHoaDon)
    Begin
        Print N'Ngày bán phải lớn hơn hoặc bằng ngày lập hóa đơn.'
        Rollback tran
    End
End
